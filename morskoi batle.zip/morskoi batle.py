#моря
r = [[0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,]]

l = [[0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,],
    [0,0,0,0,0,0,0,0,0,0,]]
#жизни
HPr = 3
HPl = 3
#очередь
t = 0

#
print("=================")
print("--morskoi batle--")
print("=================")
#выбор расположения кораблей
print("выбор расположения кораблей r user")
for i in range(3):
    r [int(input())] [int(input())] = 5
    print("ещё")

for b in range(250):
        print()


print("выбор расположения кораблей l user")
for i in range(3):
    l [int(input())] [int(input())] = 5
    print("ещё")
    
for b in range(250):
        print()

print("=================")
print("--morskoi batle--")
print("=================")


while HPr>0 and HPl>0:
    while t == 0  and HPr>0 and HPl>0:
        print("HP r user:")
        print(HPr)
        print("HP l user:")
        print(HPl)
        print("ход левого игрока")
        x = int(input())
        y = int(input())
        if r[x][y] == 5:
            r[x][y] == 0
            HPr-=1
            print("попал")
        else:
            print("непопал")
            t = 1

    while t == 1 and HPr>0 and HPl>0:
        print("HP r user:")
        print(HPr)
        print("HP l user:")
        print(HPl)
        print("ход правого игрока")
        x = int(input())
        y = int(input())
        if l[x][y] == 5:
            l[x][y] == 0
            HPl-=1
            print("попал")
        else:
            print("непопал")
            t = 0
if HPr > 0:
    print("победа правого игрока")
else:
    print("победа левого игрока")






    
    
    


      
        
        
